item_01 =int(input('Enter your Age '))
if (item_01<5):
    print('Free')
elif (item_01>=5 and item_01<=12):
     print('₹100')
elif (item_01>=13 and item_01<=59):
     print('₹200')
else :
     print('₹150')
