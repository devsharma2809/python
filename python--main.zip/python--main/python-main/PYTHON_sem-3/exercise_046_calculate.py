#1+2^2+3^3
item_01=int(input('Enter No '))
sum=0
for item_02 in range(1,item_01+1):
    sum = sum + (item_02**item_02)
print(sum)