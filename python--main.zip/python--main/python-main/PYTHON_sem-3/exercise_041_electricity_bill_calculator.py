item_01 =int(input('Enter no of Units '))
if (item_01<=100):
    item_02= item_01 *2
elif (item_01<=200):
    item_02 = (100*2) + (item_01-100) *3
elif (item_01<=300):
    item_02 = (100*2)+ (100*3) + (item_01-100) *5
else :
    item_02 = (100*2)+ (100*3) +(100*5) + (item_01-100) *7

print('Total amount of bill is =₹',item_02)