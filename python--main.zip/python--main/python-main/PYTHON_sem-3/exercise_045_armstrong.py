item_01=int(input('Enter No '))
item_02=item_01
sum = 0
while item_02>0:
    re=item_02%10
    sum+=re**3
    item_02//=10
    if(item_01==sum):
        print(item_01,"The number is armstrong")
    else:
        print(item_01,"The number is not armstrong")
