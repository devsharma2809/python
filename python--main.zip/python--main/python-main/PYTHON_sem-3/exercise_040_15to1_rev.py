for item_01 in range(15,0,-1):
    print(item_01)