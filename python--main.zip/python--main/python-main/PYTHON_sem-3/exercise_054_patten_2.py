for item_01 in range(1,6):
    for item_02 in range(1,item_01+1):
        print(item_01,item_03=" ")
    print()