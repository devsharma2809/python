#find factorial of given no
item_01=1
item_02=1
item_03=int(input('Enter No '))
while item_01<=item_03:
    item_02=item_02*item_01
    item_01=item_01+1
print(item_02)