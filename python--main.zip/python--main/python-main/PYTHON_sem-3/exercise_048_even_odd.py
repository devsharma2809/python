item_01=int(input('Enter number'))
if item_01%2==0:
    
    print('Number is even')
else :
    print('Number is odd')