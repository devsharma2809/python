#1-3+5-7+9-11 
item_01=int(input('Enter No '))
item_02 =1
sum = 0
for item_03 in range(1,item_01+1,2): 
    sum = sum + (item_03*item_02)
    item_02=item_02*-1
print(sum)