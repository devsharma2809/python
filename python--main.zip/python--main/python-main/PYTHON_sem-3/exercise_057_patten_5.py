item_01=5
for item_02 in range(1,6):
    for item_03 in range(1,item_01):
        print(item_04="  ")
    item_01=item_01-1
    for item_03 in range(1,item_02+1):
            print(item_03,item_04=" ")
    print()