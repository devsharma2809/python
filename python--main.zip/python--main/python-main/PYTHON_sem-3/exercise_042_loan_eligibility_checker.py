item_01=int(input("Enter Income "))
if item_01>=100000:
    print('Premium Loan')   
elif item_01>=50000:
    print('Standard Loan')
elif item_01>=25000:
    print('Basic Loan')
else :
    print('Not Eligible')
