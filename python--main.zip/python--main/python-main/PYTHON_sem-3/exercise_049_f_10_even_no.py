#print first 10 even no
item_01=2
while item_01<=20:
    print(item_01)
    item_01=item_01+2
print("end")