item_01,item_02,item_03,item_04=int(input('Enter 4 Number'))
if item_01>item_02 and item_01>item_03 and item_01>item_04 :
    print('Max number is: ',item_01)
elif item_02>item_01 and item_02>item_03 and item_02>item_04 :
    print('Max number is: ',item_02)
elif item_03>item_01 and item_03>item_02 and item_03>item_04 :
    print('Max number is: ',item_03)
else :
    print('Max number is: ',item_04)
