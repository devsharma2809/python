#print first 10 no
item_01=1
while item_01<=10:
    print(item_01)
    item_01=item_01+1