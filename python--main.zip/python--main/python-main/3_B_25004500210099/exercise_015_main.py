"""
PTMAE: Python Transaction Ledger & Audit Engine
=============================================================
A high-integrity transactional micro-banking and audit system built
strictly in pure Python 3.x with zero external dependencies.

HARD CONSTRAINTS ENFORCED:
- Imports: ONLY standard libraries 'random' and 'datetime'.
- Manual Parser: Zero use of str.split() or str.replace().
- Reductions: Zero use of max(), min(), sum() where loop tracking/reduction is required.
- Closures & Scope: Zero global variables used for state transfer or late binding.
- In-place Mutability: In-place queue cleaning without modifying object id() or re-binding.
- File Engine: In-place 'r+' mode record updating with chunk-wise shifting and f.truncate().
  Never rewrites entire file in 'w' mode.
- Resource Safety: All file descriptors safely managed via context managers or try-finally.
- OOP: Strictly uses super().__init__() without hardcoding base class names.
- Encapsulation: Strict name mangling for private balance and overdraft fields.
"""

# =====================================================================
# ALLOWED IMPORTS ONLY (Strictly 'random' and 'datetime')
# =====================================================================
import datetime
import random


# =====================================================================
# MODULE 1 — STATE ENGINE (Unit 1)
# =====================================================================

def calculate_compound_interest(
    ledger_value_002,
    ledger_value_003,
    ledger_value_004,
    ledger_value_005=1,
    ledger_value_006=0.0,
    ledger_value_007=0.0
):

    
    """
    Computes compound interest and conditional penalties period-by-period
    using EXCLUSIVELY basic arithmetic operators: +, -, *, /, //, %, **.
    
    Zero math module functions and zero built-in min/max/sum are used.
    All accumulation and state progressions are tracked manually within the loop.
    
    Parameters:
        principal (float): Initial account balance or principal amount.
        annual_rate (float): Nominal annual interest rate (e.g., 0.06 for 6%).
        periods (int): Total number of simulation periods.
        compounding_frequency (int): Compounding cycles per period (default 1).
        penalty_rate (float): Penalty fraction applied if below threshold (e.g., 0.02).
        penalty_threshold (float): Balance threshold triggering penalty assessment.
        
    Returns:
        tuple: (final_balance, period_history)
            final_balance (float): Resulting balance after all periods.
            period_history (list): Log of dictionaries for each period's state.
    """


    ledger_value_008 = float(ledger_value_002)
    ledger_value_009 = []
    
    # Manual loop counter
    ledger_value_010 = 0
    while ledger_value_010 < ledger_value_004:
        ledger_value_010 = ledger_value_010 + 1
        
        # Periodic rate and compounding factor using +, /, **
        ledger_value_011 = ledger_value_003 / ledger_value_005
        ledger_value_012 = (1.0 + ledger_value_011) ** ledger_value_005
        
        # New balance after compounding interest using * and -
        ledger_value_013 = ledger_value_008 * ledger_value_012
        ledger_value_014 = ledger_value_013 - ledger_value_008
        ledger_value_008 = ledger_value_013
        
        # Conditional penalty evaluation using comparison and * / -
        ledger_value_015 = 0.0
        if ledger_value_008 < ledger_value_007:
            ledger_value_015 = ledger_value_008 * ledger_value_006
            ledger_value_008 = ledger_value_008 - ledger_value_015
            
        ledger_value_009.append({
            "period": ledger_value_010,
            "interest": ledger_value_014,
            "penalty": ledger_value_015,
            "balance": ledger_value_008
        })
        
    return ledger_value_008, ledger_value_009


def check_trajectory_safety(ledger_value_017, ledger_value_018=100.0):


    """
    Evaluates an operational trajectory sequence and halts execution immediately
    upon detecting unsafe conditions using short-circuit logical operators ('and' / 'or').
    
    Condition for immediate halt:
        (balance < safety_threshold) OR (termination_flag is True)
    
    Parameters:
        sequence (iterable): Sequence of state steps (dicts, tuples, or objects).
        safety_threshold (float): Minimum permissible balance threshold.
        
    Returns:
        dict: Diagnostic summary containing execution status, halt reason,
              step count, and safe trajectory records.
    """


    ledger_value_019 = []
    ledger_value_020 = False
    ledger_value_021 = None
    ledger_value_022 = 0
    
    for ledger_value_023 in ledger_value_017:
        ledger_value_022 = ledger_value_022 + 1
        
        # Extract balance and termination flag from heterogeneous formats
        if isinstance(ledger_value_023, dict):
            ledger_value_024 = float(ledger_value_023.get("balance", 0.0))
            ledger_value_025 = ledger_value_023.get("terminate", False)
        elif isinstance(ledger_value_023, (list, tuple)):
            ledger_value_024 = float(ledger_value_023[1]) if len(ledger_value_023) > 1 else 0.0
            ledger_value_025 = ledger_value_023[2] if len(ledger_value_023) > 2 else False
        else:
            ledger_value_024 = float(getattr(ledger_value_023, "balance", 0.0))
            ledger_value_025 = getattr(ledger_value_023, "terminate", False)
            
        # Short-circuit logical evaluation:
        # If (balance < safety_threshold) evaluates to True, Python halts evaluation
        # of subsequent terms immediately, triggering the halt action.
        if (ledger_value_024 < ledger_value_018) or (ledger_value_025 is True or ledger_value_025 == "TERMINATE"):
            ledger_value_020 = True
            ledger_value_021 = (
                f"Balance {ledger_value_024:.2f} fell below safety threshold of {ledger_value_018:.2f}"
                if ledger_value_024 < ledger_value_018
                else "Explicit termination flag encountered"
            )
            break
            
        ledger_value_019.append(ledger_value_023)
        
    return {
        "halted": ledger_value_020,
        "halt_reason": ledger_value_021,
        "stopped_at_step": ledger_value_022 if ledger_value_020 else None,
        "safe_steps_count": len(ledger_value_019),
        "safe_trajectory": ledger_value_019
    }


def run_interactive_cli(ledger_value_027=None, ledger_value_028="accounts.db"):
    """
    Interactive CLI event loop built strictly with NESTED while loops.
    
    Features:
    - Continues execution after both valid and invalid commands without crashing.
    - Exits ONLY on an explicit 'exit' command.
    - Outer loop governs system runtime state; inner loop governs session command dispatch.
    
    Parameters:
        account_registry (dict, optional): In-memory account objects registry.
        db_path (str): Path to persistent accounts database file.
    """
    if ledger_value_027 is None:
        ledger_value_027 = {}
        
    print("\n" + "=" * 65)
    print(" PTMAE: Python Transaction Ledger & Audit Engine")
    print("=" * 65)
    print("Type 'help' for available commands or 'exit' to terminate.\n")
    
    ledger_value_029 = True
    
    # Outer while loop (System Runtime Level)
    while ledger_value_029:
        ledger_value_030 = True
        
        # Inner while loop (Command Dispatch & Event Processing Level)
        while ledger_value_030:
            try:
                ledger_value_031 = input("PTMAE> ")
            except (EOFError, KeyboardInterrupt):
                print("\n[CLI] Session terminated by signal. Exiting.")
                ledger_value_030 = False
                ledger_value_029 = False
                break
                
            # Manual extraction of command tokens without str.split()
            ledger_value_032 = parse_delimited_record(ledger_value_031, ledger_value_034=" ")
            
            # Filter empty strings resulting from multiple spaces
            ledger_value_035 = []
            ledger_value_036 = 0
            while ledger_value_036 < len(ledger_value_032):
                ledger_value_037 = ledger_value_032[ledger_value_036]
                if len(ledger_value_037) > 0:
                    ledger_value_035.append(ledger_value_037)
                ledger_value_036 = ledger_value_036 + 1
                
            if len(ledger_value_035) == 0:
                continue
                
            ledger_value_038 = ledger_value_035[0].lower()
            
            # 1. Exit command (The ONLY way to terminate the engine)
            if ledger_value_038 == "exit":
                print("[CLI] Shutting down PTMAE engine safely. Goodbye.")
                ledger_value_030 = False
                ledger_value_029 = False
                break
                
            # 2. Help command
            elif ledger_value_038 == "help":
                print("\nAvailable Commands:")
                print("  help                               Display this command menu")
                print("  list                               List all registered in-memory accounts")
                print("  create <id> <type> <balance>       Create an account (SAVINGS, CURRENT, CREDIT)")
                print("  deposit <id> <amount>              Deposit funds into an account")
                print("  withdraw <id> <amount>             Withdraw/settle funds from an account")
                print("  interest <p> <rate> <periods>      Simulate compound interest and penalties")
                print("  guard                              Run trajectory guard test sequence")
                print("  update <id> <type> <balance>       Update database record in-place via r+ mode")
                print("  audit                              Process and audit accounts database")
                print("  settle <amount>                    Run polymorphic batch settlement on all accounts")
                print("  exit                               Exit the application\n")
                
            # 3. List command
            elif ledger_value_038 == "list":
                if len(ledger_value_027) == 0:
                    print("[INFO] No in-memory accounts registered. Use 'create' command or run demonstration.")
                else:
                    print("\n--- In-Memory Accounts ---")
                    for ledger_value_039, ledger_value_040 in ledger_value_027.items():
                        print(f"  Account ID: {ledger_value_039:<10} | Type: {type(ledger_value_040).__name__:<16} | Balance: {ledger_value_040.get_balance():.2f}")
                    print(f"Total Active Account Objects: {BankAccount.total_accounts}\n")
                    
            # 4. Create command
            elif ledger_value_038 == "create":
                if len(ledger_value_035) < 4:
                    print("[ERROR] Usage: create <account_id> <SAVINGS|CURRENT|CREDIT> <balance>")
                    continue
                ledger_value_039 = ledger_value_035[1]
                ledger_value_042 = ledger_value_035[2].upper()
                try:
                    ledger_value_043 = float(ledger_value_035[3])
                except ValueError:
                    print(f"[ERROR] Balance must be numeric. Received: '{ledger_value_035[3]}'")
                    continue
                    
                if ledger_value_042 == "SAVINGS":
                    ledger_value_027[ledger_value_039] = SavingsAccount(ledger_value_039, ledger_value_043)
                elif ledger_value_042 == "CURRENT":
                    ledger_value_027[ledger_value_039] = CurrentAccount(ledger_value_039, ledger_value_043)
                elif ledger_value_042 == "CREDIT":
                    ledger_value_027[ledger_value_039] = CreditAccount(ledger_value_039, ledger_value_043)
                else:
                    print(f"[ERROR] Unknown account type: '{ledger_value_042}'. Must be SAVINGS, CURRENT, or CREDIT.")
                    continue
                print(f"[SUCCESS] Created {ledger_value_042} account '{ledger_value_039}' with initial balance {ledger_value_043:.2f}")
                
            # 5. Deposit command
            elif ledger_value_038 == "deposit":
                if len(ledger_value_035) < 3:
                    print("[ERROR] Usage: deposit <account_id> <amount>")
                    continue
                ledger_value_039 = ledger_value_035[1]
                if ledger_value_039 not in ledger_value_027:
                    print(f"[ERROR] Account '{ledger_value_039}' not found in registry.")
                    continue
                try:
                    ledger_value_047 = float(ledger_value_035[2])
                    if ledger_value_047 <= 0.0:
                        raise ValueError("Amount must be positive.")
                except ValueError as ledger_value_048:
                    print(f"[ERROR] Invalid deposit amount: {ledger_value_048}")
                    continue
                ledger_value_040 = ledger_value_027[ledger_value_039]
                ledger_value_040.set_balance(ledger_value_040.get_balance() + ledger_value_047)
                print(f"[SUCCESS] Deposited {ledger_value_047:.2f} into '{ledger_value_039}'. New Balance: {ledger_value_040.get_balance():.2f}")
                
            # 6. Withdraw / Settle command
            elif ledger_value_038 == "withdraw":
                if len(ledger_value_035) < 3:
                    print("[ERROR] Usage: withdraw <account_id> <amount>")
                    continue
                ledger_value_039 = ledger_value_035[1]
                if ledger_value_039 not in ledger_value_027:
                    print(f"[ERROR] Account '{ledger_value_039}' not found in registry.")
                    continue
                try:
                    ledger_value_047 = float(ledger_value_035[2])
                    if ledger_value_047 <= 0.0:
                        raise ValueError("Amount must be positive.")
                except ValueError as ledger_value_048:
                    print(f"[ERROR] Invalid withdrawal amount: {ledger_value_048}")
                    continue
                ledger_value_040 = ledger_value_027[ledger_value_039]
                try:
                    ledger_value_049 = ledger_value_040.process_settlement(ledger_value_047)
                    print(f"[SUCCESS] Settlement completed for '{ledger_value_039}'. New Balance: {ledger_value_049['new_balance']:.2f}")
                except BankingEngineError as ledger_value_051:
                    print(f"[REJECTED] Settlement failed for '{ledger_value_039}': {ledger_value_051}")
                    
            # 7. Interest command
            elif ledger_value_038 == "interest":
                if len(ledger_value_035) < 4:
                    print("[ERROR] Usage: interest <principal> <annual_rate> <periods>")
                    continue
                try:
                    ledger_value_052 = float(ledger_value_035[1])
                    ledger_value_053 = float(ledger_value_035[2])
                    ledger_value_054 = int(ledger_value_035[3])
                except ValueError:
                    print("[ERROR] Principal, rate, and periods must be numeric.")
                    continue
                ledger_value_055, ledger_value_056 = calculate_compound_interest(
                    ledger_value_052, ledger_value_053, ledger_value_054, ledger_value_005=1, ledger_value_006=0.02, ledger_value_007=500.0
                )
                print(f"[SIMULATION] Final Balance after {ledger_value_054} periods: {ledger_value_055:.2f}")
                print(f"             Total Interest/Penalty logs generated: {len(ledger_value_056)}")
                
            # 8. Guard command
            elif ledger_value_038 == "guard":
                ledger_value_057 = [
                    {"step": 1, "balance": 1200.0, "terminate": False},
                    {"step": 2, "balance": 450.0, "terminate": False},
                    {"step": 3, "balance": 80.0, "terminate": False}, # Falls below 100.0
                    {"step": 4, "balance": 2000.0, "terminate": False}
                ]
                ledger_value_058 = check_trajectory_safety(ledger_value_057, ledger_value_018=100.0)
                print(f"[GUARD] Result: Halted={ledger_value_058['halted']} | Reason: {ledger_value_058['halt_reason']}")
                print(f"        Processed {ledger_value_058['safe_steps_count']} safe steps out of {len(ledger_value_057)}.")
                
            # 9. Update command (in-place file engine)
            elif ledger_value_038 == "update":
                if len(ledger_value_035) < 4:
                    print("[ERROR] Usage: update <account_id> <type> <balance>")
                    continue
                ledger_value_039 = ledger_value_035[1]
                ledger_value_042 = ledger_value_035[2].upper()
                try:
                    ledger_value_059 = float(ledger_value_035[3])
                except ValueError:
                    print("[ERROR] Balance must be numeric.")
                    continue
                try:
                    update_account_record_in_place(ledger_value_028, ledger_value_039, ledger_value_061=ledger_value_042, ledger_value_013=ledger_value_059)
                    print(f"[SUCCESS] Database record for '{ledger_value_039}' updated in-place via r+ mode.")
                except BankingEngineError as ledger_value_062:
                    print(f"[ERROR] Database update failed: {ledger_value_062}")
                except Exception as ledger_value_063:
                    print(f"[ERROR] File error: {ledger_value_063}")
                    
            # 10. Audit command
            elif ledger_value_038 == "audit":
                print("[INFO] Starting accounts database audit...")
                audit_accounts_file(ledger_value_028=ledger_value_028)
                
            # 11. Settle command (Batch polymorphic settlement)
            elif ledger_value_038 == "settle":
                if len(ledger_value_035) < 2:
                    print("[ERROR] Usage: settle <amount>")
                    continue
                try:
                    ledger_value_065 = float(ledger_value_035[1])
                except ValueError:
                    print("[ERROR] Settle amount must be numeric.")
                    continue
                ledger_value_066 = list(ledger_value_027.values())
                if len(ledger_value_066) == 0:
                    print("[INFO] No in-memory accounts to settle. Create some first.")
                    continue
                ledger_value_067 = execute_batch_settlement(ledger_value_066, ledger_value_065)
                print(f"[BATCH REPORT] Successes: {ledger_value_067['success_count']} | Failures: {ledger_value_067['failure_count']}")
                
            # Unknown / Invalid command (Continues loop safely)
            else:
                print(f"[ERROR] Unknown command: '{ledger_value_035[0]}'. Type 'help' for command list.")


# =====================================================================
# MODULE 2 — LOG PARSER & CLOSURES (Unit 2)
# =====================================================================

def parse_delimited_record(ledger_value_069, ledger_value_034=",", ledger_value_070='"'):
    """
    Parses a raw delimited string into clean string tokens MANUALLY.
    
    STRICT CONSTRAINTS SATISFIED:
    - Zero use of str.split() or str.replace().
    - Zero use of the csv module or regular expressions.
    - Uses explicit index tracking, character iteration, slicing, and state flags.
    - Correctly handles delimiters inside quoted fields as literal data.
    - Handles escaped quote pairs ("") inside quoted fields as a single literal quote.
    - Accurately captures empty fields and trailing delimiters.
    
    Parameters:
        line (str): Input log string line.
        delimiter (str): Field separator (default ',').
        quote_char (str): Quoting character (default '"').
        
    Returns:
        list: List of parsed string tokens.
    """
    # Strip trailing newline characters manually using slicing
    while len(ledger_value_069) > 0 and ledger_value_069[-1] in ("\n", "\r"):
        ledger_value_069 = ledger_value_069[:-1]
        
    if len(ledger_value_069) == 0:
        return []
        
    ledger_value_071 = []
    ledger_value_072 = []
    ledger_value_073 = False
    ledger_value_074 = 0
    ledger_value_075 = len(ledger_value_069)
    
    while ledger_value_074 < ledger_value_075:
        ledger_value_076 = ledger_value_069[ledger_value_074]
        
        if ledger_value_073:
            if ledger_value_076 == ledger_value_070:
                # Check for escaped quote pair ("")
                if ledger_value_074 + 1 < ledger_value_075 and ledger_value_069[ledger_value_074 + 1] == ledger_value_070:
                    ledger_value_072.append(ledger_value_070)
                    ledger_value_074 = ledger_value_074 + 2
                    continue
                else:
                    # Closing quote
                    ledger_value_073 = False
                    ledger_value_074 = ledger_value_074 + 1
                    continue
            else:
                ledger_value_072.append(ledger_value_076)
                ledger_value_074 = ledger_value_074 + 1
                continue
        else:
            if ledger_value_076 == ledger_value_070:
                # Opening quote
                ledger_value_073 = True
                ledger_value_074 = ledger_value_074 + 1
                continue
            elif ledger_value_076 == ledger_value_034:
                # Field boundary reached
                ledger_value_071.append("".join(ledger_value_072))
                ledger_value_072 = []
                ledger_value_074 = ledger_value_074 + 1
                continue
            else:
                ledger_value_072.append(ledger_value_076)
                ledger_value_074 = ledger_value_074 + 1
                continue
                
    # Append final token after loop terminates
    ledger_value_071.append("".join(ledger_value_072))
    return ledger_value_071


def create_audit_filter(ledger_value_078):


    """
    Factory creating a stateful audit filter closure.
    
    CONSTRAINTS SATISFIED:
    - Returns a nested function using the 'nonlocal' keyword to maintain
      an independent count of audited records across successive invocations.
    - Zero global variables used.
    - Each filter instance maintains completely isolated state.
    
    Parameters:
        threshold (float): Minimum financial value triggering audit qualification.
        
    Returns:
        function: Filter closure accepting a record and returning boolean qualification.
    """


    ledger_value_079 = 0
    ledger_value_080 = 0
    
    def ledger_value_081(ledger_value_082):
        nonlocal ledger_value_079, ledger_value_080
        ledger_value_079 = ledger_value_079 + 1
        
        # Extract numerical value from record
        ledger_value_083 = 0.0
        if isinstance(ledger_value_082, (int, float)):
            ledger_value_083 = float(ledger_value_082)
        elif isinstance(ledger_value_082, dict):
            ledger_value_083 = float(ledger_value_082.get("balance", ledger_value_082.get("amount", 0.0)))
        elif isinstance(ledger_value_082, (list, tuple)) and len(ledger_value_082) >= 3:
            try:
                ledger_value_083 = float(ledger_value_082[2])
            except (ValueError, TypeError):
                ledger_value_083 = 0.0
        elif hasattr(ledger_value_082, "get_balance"):
            ledger_value_083 = float(ledger_value_082.get_balance())
            
        ledger_value_084 = (ledger_value_083 >= ledger_value_078)
        if ledger_value_084:
            ledger_value_080 = ledger_value_080 + 1
            
        return ledger_value_084

    def ledger_value_085():


        """Returns the internal state of this specific filter closure."""


        nonlocal ledger_value_079, ledger_value_080
        return {
            "total_audited": ledger_value_079,
            "total_passed": ledger_value_080,
            "threshold": ledger_value_078
        }
        
    ledger_value_081.get_stats = ledger_value_085
    return ledger_value_081


def build_position_filters(ledger_value_087):


    """
    Builds a list of lambda filters in a loop where each lambda tests the
    k-th positional criterion of a record.
    
    CONSTRAINTS SATISFIED:
    - Avoids Python closure late-binding by binding the loop index k as a
      default argument (k=k).
    - Zero global variables used.
    
    Parameters:
        criteria_callables (list): List of predicate functions for each position.
        
    Returns:
        list: List of lambda filters [lambda rec, k=k: ...]
    """


    ledger_value_088 = []
    
    for ledger_value_089 in range(len(ledger_value_087)):
        # k=k binds current iteration value of k at definition time
        ledger_value_088.append(
            lambda ledger_value_082, ledger_value_089=ledger_value_089: ledger_value_087[ledger_value_089](ledger_value_082[ledger_value_089]) if ledger_value_089 < len(ledger_value_082) else False
        )
        
    return ledger_value_088


# =====================================================================
# MODULE 3 — DATA INVERSION & IN-PLACE PROCESSING (Unit 3)
# =====================================================================

def invert_service_catalog(ledger_value_091):


    """
    Transforms a branch-indexed bank service database into a service-indexed
    reverse index using a SINGLE dict comprehension pipeline.
    
    Format:
        Input:
            raw_db = {
                "BRANCH_01": [("Acc1@1", {"DEPOSIT", "UPI"}), ("Acc1@2", {"LOAN", "UPI"})],
                "BRANCH_02": [("Acc101", {"SAVINGS", "UPI"}), ("Acc103", {"CARD", "DEPOSIT"})]
            }
        Output:
            key = service tag,
            value = alphabetically sorted list of unique (Account_ID, Branch_ID) tuples.
            
    CONSTRAINTS SATISFIED:
    - Implemented strictly with a SINGLE dict comprehension.
    - Values are unique and sorted alphabetically.
    
    Parameters:
        raw_db (dict): Branch-mapped accounts and service sets.
        
    Returns:
        dict: Inverted service catalog index.
    """


    return {
        ledger_value_092: sorted(list({
            (ledger_value_093, ledger_value_094)
            for ledger_value_094, ledger_value_095 in ledger_value_091.items()
            for ledger_value_093, ledger_value_096 in ledger_value_095
            if ledger_value_092 in ledger_value_096
        }))
        for ledger_value_092 in sorted({
            ledger_value_097
            for ledger_value_095 in ledger_value_091.values()
            for ledger_value_098, ledger_value_096 in ledger_value_095
            for ledger_value_097 in ledger_value_096
        })
    }


def clean_transaction_queue(ledger_value_100):


    """
    Cleans a heterogeneous transaction queue IN-PLACE without creating a new list.
    
    STRICT CONSTRAINTS SATISFIED:
    - id(data_list) remains 100% unchanged before and after execution.
    - Zero re-binding of parameter (data_list = [...] is strictly forbidden).
    - Step 1: Converts every tuple element into a list.
    - Step 2: Removes even-numbered transaction IDs from every set via set difference.
    - Step 3: Sorts every embedded list descending.
    - Step 4: Removes duplicate primitive values by scanning the list and DELETING
              BY INDEX (del data_list[i]) with ZERO separate collections (no seen set/dict/list).
              
    Parameters:
        data_list (list): Heterogeneous transaction queue containing tuples,
                          lists, sets, numbers, and strings.
                          
    Returns:
        list: The exact same list object mutated in-place.
    """


    # Step 1: Convert every tuple element into a list
    ledger_value_101 = 0
    while ledger_value_101 < len(ledger_value_100):
        if isinstance(ledger_value_100[ledger_value_101], tuple):
            ledger_value_100[ledger_value_101] = list(ledger_value_100[ledger_value_101])
        ledger_value_101 = ledger_value_101 + 1

    # Step 2: Remove even-numbered transaction IDs from every set via set difference
    ledger_value_101 = 0
    while ledger_value_101 < len(ledger_value_100):
        if isinstance(ledger_value_100[ledger_value_101], set):
            ledger_value_102 = {ledger_value_103 for ledger_value_103 in ledger_value_100[ledger_value_101] if isinstance(ledger_value_103, int) and ledger_value_103 % 2 == 0}
            ledger_value_100[ledger_value_101] = ledger_value_100[ledger_value_101].difference(ledger_value_102)
        ledger_value_101 = ledger_value_101 + 1

    # Step 3: Sort every embedded list descending
    ledger_value_101 = 0
    while ledger_value_101 < len(ledger_value_100):
        if isinstance(ledger_value_100[ledger_value_101], list):
            try:
                ledger_value_100[ledger_value_101].sort(reverse=True)
            except TypeError:
                # Heterogeneous fallback sorting using string representation
                ledger_value_100[ledger_value_101].sort(key=lambda ledger_value_106: str(ledger_value_106), reverse=True)
        ledger_value_101 = ledger_value_101 + 1

    # Step 4: Remove duplicate primitive values by scanning and DELETING BY INDEX
    # Strictly zero separate collections (no set, no dict, no tracking list)
    ledger_value_074 = 0
    while ledger_value_074 < len(ledger_value_100):
        ledger_value_107 = ledger_value_100[ledger_value_074]
        # Identify primitive types: int, float, str, bool
        if isinstance(ledger_value_107, (int, float, str, bool)) and ledger_value_107 is not None:
            ledger_value_108 = False
            ledger_value_109 = 0
            while ledger_value_109 < ledger_value_074:
                ledger_value_110 = ledger_value_100[ledger_value_109]
                # Type identity check ensures True != 1 and False != 0
                if type(ledger_value_110) is type(ledger_value_107) and ledger_value_110 == ledger_value_107:
                    ledger_value_108 = True
                    break
                ledger_value_109 = ledger_value_109 + 1
                
            if ledger_value_108:
                del ledger_value_100[ledger_value_074]
                # Index shifts left, so do not increment i
                continue
                
        ledger_value_074 = ledger_value_074 + 1

    return ledger_value_100


# =====================================================================
# MODULE 4 — FILE ENGINE & LOGGING (Unit 4)
# =====================================================================

class BankingEngineError(Exception):
    """Root exception class for all PTMAE transactional engine errors."""
    pass


class CorruptRecordError(BankingEngineError):
    """Raised when an account record in database contains invalid, unparseable, or corrupt data."""
    pass


class OperationalLimitError(BankingEngineError):
    """Raised when an operational limit (e.g. overdraft ceiling or index boundary) is exceeded."""
    pass


class InsufficientBalanceError(BankingEngineError):
    """Raised when an account lacks sufficient balance to perform a settlement or satisfy minimums."""
    pass


def update_account_record_in_place(ledger_value_114, ledger_value_115, ledger_value_061=None, ledger_value_013=None):

    """
    Updates a specific account record in accounts.db in 'r+' mode.
    
    STRICT CONSTRAINTS SATISFIED:
    - Opens strictly in 'r+' mode with 'with' statement.
    - NEVER reads the entire file into memory or rewrites with 'w' mode.
    - Locates records with f.tell() and f.seek().
    - If payload size is identical, overwrites in place directly.
    - If payload shrinks (delta < 0), overwrites and shifts file remainder
      backwards in fixed-size chunks, then calls f.truncate().
    - If payload expands (delta > 0), shifts file remainder forwards from EOF
      backwards in fixed-size chunks, then writes new record at exact byte position.
    - Zero damage to neighbouring or adjacent lines.
    
    Parameters:
        file_path (str): Path to accounts.db.
        target_account_id (str): Account ID to locate and update.
        new_account_type (str, optional): Updated account type.
        new_balance (float, optional): Updated account balance.
    """


    ledger_value_116 = 64
    
    with open(ledger_value_114, "r+", newline="\n", encoding="utf-8") as ledger_value_119:
        ledger_value_120 = False
        ledger_value_121 = None
        ledger_value_122 = None
        
        # Pass 1: Locate target record and record byte offsets
        ledger_value_119.seek(0)
        while True:
            ledger_value_123 = ledger_value_119.tell()
            ledger_value_069 = ledger_value_119.readline()
            if not ledger_value_069:
                break
                
            ledger_value_071 = parse_delimited_record(ledger_value_069)
            if len(ledger_value_071) >= 1 and ledger_value_071[0] == ledger_value_115:
                ledger_value_120 = True
                ledger_value_121 = ledger_value_123
                ledger_value_122 = ledger_value_069
                break
                
        if not ledger_value_120:
            raise OperationalLimitError(f"Account '{ledger_value_115}' not found in database '{ledger_value_114}'.")
            
        ledger_value_124 = parse_delimited_record(ledger_value_122)
        ledger_value_125 = ledger_value_124[1] if len(ledger_value_124) > 1 else "SAVINGS"
        ledger_value_126 = ledger_value_124[2] if len(ledger_value_124) > 2 else "0.00"
        
        ledger_value_127 = ledger_value_061 if ledger_value_061 is not None else ledger_value_125
        if ledger_value_013 is not None:
            ledger_value_128 = f"{ledger_value_013:.2f}"
        else:
            ledger_value_128 = ledger_value_126
            
        ledger_value_129 = f"{ledger_value_115},{ledger_value_127},{ledger_value_128}\n"
        
        ledger_value_130 = len(ledger_value_122)
        ledger_value_131 = len(ledger_value_129)
        ledger_value_132 = ledger_value_131 - ledger_value_130
        ledger_value_133 = ledger_value_121 + ledger_value_130
        
        # Case A: Identical payload size (Direct byte overwrite)
        if ledger_value_132 == 0:
            ledger_value_119.seek(ledger_value_121)
            ledger_value_119.write(ledger_value_129)
            ledger_value_119.flush()
            
        # Case B: Shrinking payload (delta < 0)
        elif ledger_value_132 < 0:
            # Overwrite updated line first
            ledger_value_119.seek(ledger_value_121)
            ledger_value_119.write(ledger_value_129)
            
            # Shift remainder of file backwards in chunks
            ledger_value_134 = ledger_value_133
            ledger_value_135 = ledger_value_121 + ledger_value_131
            
            while True:
                ledger_value_119.seek(ledger_value_134)
                ledger_value_136 = ledger_value_119.read(ledger_value_116)
                if not ledger_value_136:
                    break
                ledger_value_134 = ledger_value_119.tell()
                
                ledger_value_119.seek(ledger_value_135)
                ledger_value_119.write(ledger_value_136)
                ledger_value_135 = ledger_value_119.tell()
                
            # Truncate discarded trailing bytes
            ledger_value_119.truncate(ledger_value_135)
            ledger_value_119.flush()
            
        # Case C: Expanding payload (delta > 0)
        else:
            # Move from EOF backwards to avoid overwriting unread data
            ledger_value_119.seek(0, 2)
            ledger_value_137 = ledger_value_119.tell()
            ledger_value_138 = ledger_value_137
            
            while ledger_value_138 > ledger_value_133:
                ledger_value_139 = ledger_value_138 - ledger_value_133
                ledger_value_140 = ledger_value_116 if ledger_value_139 > ledger_value_116 else ledger_value_139
                ledger_value_141 = ledger_value_138 - ledger_value_140
                
                ledger_value_119.seek(ledger_value_141)
                ledger_value_136 = ledger_value_119.read(ledger_value_140)
                
                ledger_value_119.seek(ledger_value_141 + ledger_value_132)
                ledger_value_119.write(ledger_value_136)
                ledger_value_138 = ledger_value_141
                
            # Write new line in allocated expanded gap
            ledger_value_119.seek(ledger_value_121)
            ledger_value_119.write(ledger_value_129)
            ledger_value_119.flush()


def audit_accounts_file(ledger_value_028="accounts.db", ledger_value_142="ledger.txt", ledger_value_143="corrupted.log"):


    """
    Audits accounts.db record-by-record using try-except-else-finally per record.
    
    STRICT CONSTRAINTS SATISFIED:
    - Detects corrupted records: wrong field count (!= 3), unknown account type,
      or non-numeric balance.
    - Valid records appended to ledger.txt with datetime timestamp.
    - Corrupted records appended to corrupted.log WITH EXACT LINE NUMBER.
    - finally block on every run reports processed and rejected record counts.
    - Zero use of max(), min(), sum().
    
    Parameters:
        db_path (str): Database file path.
        ledger_path (str): Ledger audit file path.
        corrupted_log_path (str): Corrupted records log path.
        
    Returns:
        dict: Summary of audit run (processed_count, rejected_count).
    """
    
    ledger_value_144 = 0
    ledger_value_145 = 0
    ledger_value_146 = 0
    
    try:
        with open(ledger_value_028, "r", newline="\n", encoding="utf-8") as ledger_value_147:
            while True:
                ledger_value_069 = ledger_value_147.readline()
                if not ledger_value_069:
                    break
                    
                ledger_value_146 = ledger_value_146 + 1
                
                # Per-record try-except-else-finally
                ledger_value_148 = False
                ledger_value_149 = None
                ledger_value_150 = None
                
                try:
                    ledger_value_071 = parse_delimited_record(ledger_value_069)
                    if len(ledger_value_071) != 3:
                        raise CorruptRecordError(
                            f"Field count violation: Expected exactly 3 fields, found {len(ledger_value_071)}"
                        )
                    ledger_value_093 = ledger_value_071[0].strip()
                    ledger_value_151 = ledger_value_071[1].strip()
                    ledger_value_152 = ledger_value_071[2].strip()
                    
                    if ledger_value_151 not in ("SAVINGS", "CURRENT", "CREDIT"):
                        raise CorruptRecordError(
                            f"Unknown account type '{ledger_value_151}'. Must be SAVINGS, CURRENT, or CREDIT"
                        )
                        
                    try:
                        ledger_value_153 = float(ledger_value_152)
                    except ValueError:
                        raise CorruptRecordError(f"Non-numeric balance value: '{ledger_value_152}'")
                        
                    ledger_value_149 = (ledger_value_093, ledger_value_151, ledger_value_153)
                    ledger_value_148 = True
                    
                except CorruptRecordError as ledger_value_062:
                    ledger_value_150 = ledger_value_062
                    ledger_value_145 = ledger_value_145 + 1
                    with open(ledger_value_143, "a", newline="\n", encoding="utf-8") as ledger_value_154:
                        ledger_value_154.write(f"Line {ledger_value_146}: {ledger_value_069.strip()} | Error: {ledger_value_062}\n")
                        
                else:
                    ledger_value_144 = ledger_value_144 + 1
                    ledger_value_155 = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    with open(ledger_value_142, "a", newline="\n", encoding="utf-8") as ledger_value_156:
                        ledger_value_156.write(
                            f"[{ledger_value_155}] AUDIT_OK | Account: {ledger_value_149[0]} | "
                            f"Type: {ledger_value_149[1]} | Balance: {ledger_value_149[2]:.2f}\n"
                        )
                        
                finally:
                    # Per-record audit trail confirmation
                    pass
                    
    finally:
        # Mandatory finally block reporting counts on every run
        print(f"\n[AUDIT RUN SUMMARY]")
        print(f"  Processed Valid Records : {ledger_value_144}")
        print(f"  Rejected Corrupt Records: {ledger_value_145}")
        print(f"  Total Lines Evaluated   : {ledger_value_146}")
        
    return {
        "processed_count": ledger_value_144,
        "rejected_count": ledger_value_145,
        "total_lines": ledger_value_146
    }


# =====================================================================
# MODULE 5 — OOP & POLYMORPHISM (Unit 5)
# =====================================================================

class BankAccount:
    """
    Abstract Base Account class providing foundational banking behaviors.
    
    STRICT CONSTRAINTS SATISFIED:
    - Encapsulation: private __balance, protected _account_id.
    - Class attribute total_accounts incremented upon instantiation.
    - Public getters and setters validating types and bounds.
    - Demonstrates Python name mangling (_BankAccount__balance).
    """
    total_accounts = 0
    
    def __init__(self, ledger_value_158, ledger_value_159=0.0):
        """
        Initializes an Account instance.
        
        Parameters:
            account_id (str): Unique account identifier.
            initial_balance (float): Initial opening balance.
        """
        BankAccount.total_accounts = BankAccount.total_accounts + 1
        self._account_id = str(ledger_value_158)
        
        # Validate balance type and assign to private attribute
        if not isinstance(ledger_value_159, (int, float)):
            raise TypeError("Initial balance must be a numeric value (int or float).")
        self.__balance = float(ledger_value_159)
        
    def get_account_id(self):
        """Returns the protected account identifier."""
        return self._account_id
        
    def get_balance(self):
        """Public getter for private __balance."""
        return self.__balance
        
    def set_balance(self, ledger_value_013):
        """
        Public setter for private __balance with strict validation.
        
        Parameters:
            new_balance (float): Updated balance value.
        """
        if not isinstance(ledger_value_013, (int, float)):
            raise TypeError("Balance must be a numeric value (int or float).")
        self.__balance = float(ledger_value_013)
        
    def process_settlement(self, ledger_value_164):
        """
        Polymorphic base settlement method. Subclasses override this method
        to apply specialized business constraints.
        """
        raise NotImplementedError("Subclasses must implement process_settlement().")


class SavingsAccount(BankAccount):
    """
    Savings Account with minimum balance enforcement.
    
    CONSTRAINTS SATISFIED:
    - Inherits from Account and calls super().__init__() without hardcoded base name.
    - Rejects settlement if remaining balance would fall below 1000.00
      (raises InsufficientBalanceError).
    """
    MINIMUM_BALANCE = 1000.00
    
    def __init__(self, ledger_value_158, ledger_value_159=0.0):
        super().__init__(ledger_value_158, ledger_value_159)
        
    def process_settlement(self, ledger_value_164):
        """
        Deducts settlement amount if remaining balance satisfies minimum threshold.
        """
        if not isinstance(ledger_value_164, (int, float)) or ledger_value_164 <= 0.0:
            raise TypeError("Settlement amount must be a positive numeric value.")
            
        ledger_value_166 = self.get_balance()
        ledger_value_167 = ledger_value_166 - ledger_value_164
        
        if ledger_value_167 < self.MINIMUM_BALANCE:
            raise InsufficientBalanceError(
                f"Settlement rejected for SavingsAccount '{self._account_id}': "
                f"Remaining balance {ledger_value_167:.2f} falls below required minimum of {self.MINIMUM_BALANCE:.2f}"
            )
            
        self.set_balance(ledger_value_167)
        return {
            "account_id": self._account_id,
            "type": "SAVINGS",
            "settled_amount": ledger_value_164,
            "new_balance": self.get_balance()
        }


class CurrentAccount(BankAccount):
    """
    Current Account supporting overdraft facilities up to a private limit.
    
    CONSTRAINTS SATISFIED:
    - Inherits from Account and calls super().__init__() without hardcoded base name.
    - Encapsulates private __overdraft_limit with getter/setter.
    - Allows balance to go negative down to -__overdraft_limit.
    - Raises OutOfBoundsError if settlement exceeds overdraft ceiling.
    """
    def __init__(self, ledger_value_158, ledger_value_159=0.0, ledger_value_168=5000.00):
        super().__init__(ledger_value_158, ledger_value_159)
        if not isinstance(ledger_value_168, (int, float)) or ledger_value_168 < 0.0:
            raise TypeError("Overdraft limit must be a non-negative numeric value.")
        self.__overdraft_limit = float(ledger_value_168)
        
    def get_overdraft_limit(self):
        """Getter for private __overdraft_limit."""
        return self.__overdraft_limit
        
    def set_overdraft_limit(self, ledger_value_171):
        """Setter for private __overdraft_limit."""
        if not isinstance(ledger_value_171, (int, float)) or ledger_value_171 < 0.0:
            raise TypeError("Overdraft limit must be a non-negative numeric value.")
        self.__overdraft_limit = float(ledger_value_171)
        
    def process_settlement(self, ledger_value_164):
        """
        Deducts settlement amount permitting overdraft up to private limit.
        """
        if not isinstance(ledger_value_164, (int, float)) or ledger_value_164 <= 0.0:
            raise TypeError("Settlement amount must be a positive numeric value.")
            
        ledger_value_166 = self.get_balance()
        ledger_value_167 = ledger_value_166 - ledger_value_164
        
        if ledger_value_167 < -self.__overdraft_limit:
            raise OperationalLimitError(
                f"Settlement rejected for CurrentAccount '{self._account_id}': "
                f"Projected balance {ledger_value_167:.2f} exceeds overdraft limit of {self.__overdraft_limit:.2f}"
            )
            
        self.set_balance(ledger_value_167)
        return {
            "account_id": self._account_id,
            "type": "CURRENT",
            "settled_amount": ledger_value_164,
            "new_balance": self.get_balance()
        }


class CreditAccount(BankAccount):
    """
    Credit Account applying a surcharge and deducting from available credit limit.
    
    CONSTRAINTS SATISFIED:
    - Inherits from Account and calls super().__init__() without hardcoded base name.
    - Adds a mandatory 2.5% surcharge to settlement amount before deducting.
    - Raises InsufficientBalanceError if total charge exceeds available credit limit.
    """
    SURCHARGE_RATE = 0.025 # 2.5% surcharge
    
    def __init__(self, ledger_value_158, ledger_value_173=10000.00):
        super().__init__(ledger_value_158, ledger_value_173)
        
    def process_settlement(self, ledger_value_164):
        """
        Adds 2.5% surcharge to amount and deducts from available credit limit.
        """
        if not isinstance(ledger_value_164, (int, float)) or ledger_value_164 <= 0.0:
            raise TypeError("Settlement amount must be a positive numeric value.")
            
        ledger_value_174 = ledger_value_164 * self.SURCHARGE_RATE
        ledger_value_175 = ledger_value_164 + ledger_value_174
        ledger_value_166 = self.get_balance()
        ledger_value_167 = ledger_value_166 - ledger_value_175
        
        if ledger_value_167 < 0.0:
            raise InsufficientBalanceError(
                f"Settlement rejected for CreditAccount '{self._account_id}': "
                f"Total required deduction {ledger_value_175:.2f} (including 2.5% surcharge {ledger_value_174:.2f}) "
                f"exceeds available credit limit of {ledger_value_166:.2f}"
            )
            
        self.set_balance(ledger_value_167)
        return {
            "account_id": self._account_id,
            "type": "CREDIT",
            "base_amount": ledger_value_164,
            "surcharge": ledger_value_174,
            "total_deduction": ledger_value_175,
            "new_balance": self.get_balance()
        }


def execute_batch_settlement(ledger_value_176, ledger_value_177):
    """
    Executes polymorphic settlements across a heterogeneous list of accounts.
    
    STRICT CONSTRAINTS SATISFIED:
    - Polymorphic dispatch: invokes acc.process_settlement() dynamically.
    - Isolation: EACH settlement call is wrapped in its own isolated try-except
      block so a failure on one account never aborts subsequent accounts.
    - Reductions: Zero use of max(), min(), sum() for loop tracking or totals.
    
    Parameters:
        account_list (list): Collection of Account subclass instances.
        transaction_amount (float): Settlement amount to apply.
        
    Returns:
        dict: Summary containing success_count, failure_count, success_logs,
              and failure_logs.
    """
    ledger_value_178 = []
    ledger_value_179 = []
    ledger_value_180 = 0
    ledger_value_181 = 0
    ledger_value_182 = 0.0
    
    for ledger_value_040 in ledger_value_176:
        try:
            ledger_value_049 = ledger_value_040.process_settlement(ledger_value_177)
            ledger_value_178.append(ledger_value_049)
            ledger_value_180 = ledger_value_180 + 1
            ledger_value_182 = ledger_value_182 + ledger_value_177
        except BankingEngineError as ledger_value_062:
            ledger_value_179.append({
                "account_id": ledger_value_040.get_account_id(),
                "account_type": type(ledger_value_040).__name__,
                "error": str(ledger_value_062)
            })
            ledger_value_181 = ledger_value_181 + 1
        except Exception as ledger_value_183:
            ledger_value_179.append({
                "account_id": ledger_value_040.get_account_id(),
                "account_type": type(ledger_value_040).__name__,
                "error": f"Unexpected error: {ledger_value_183}"
            })
            ledger_value_181 = ledger_value_181 + 1
            
    return {
        "success_count": ledger_value_180,
        "failure_count": ledger_value_181,
        "total_settled_volume": ledger_value_182,
        "success_logs": ledger_value_178,
        "failure_logs": ledger_value_179
    }


# =====================================================================
# VERIFICATION & DEMONSTRATION SUITE
# =====================================================================

def run_demonstrations():
    """
    Runs an exhaustive demonstration exercising every functional requirement
    (FR-1.1 through FR-5.3) and verifying non-functional rules.
    """
    print("\n" + "=" * 75)
    print(" PTMAE: COMPREHENSIVE VERIFICATION & DEMONSTRATION SUITE")
    print("=" * 75)

    # -----------------------------------------------------------------
    # UNIT 1 DEMONSTRATION: State Engine
    # -----------------------------------------------------------------
    print("\n>>> [UNIT 1] State Engine: Compound Interest & Trajectory Guard")
    ledger_value_002 = 1000.0
    ledger_value_185 = 0.08
    ledger_value_004 = 5
    ledger_value_186, ledger_value_056 = calculate_compound_interest(
        ledger_value_002=ledger_value_002,
        ledger_value_003=ledger_value_185,
        ledger_value_004=ledger_value_004,
        ledger_value_005=4,
        ledger_value_006=0.05,
        ledger_value_007=1200.0
    )
    print(f"  Compound Interest Simulation:")
    print(f"    Principal: {ledger_value_002:.2f} | Annual Rate: {ledger_value_185*100}% | Periods: {ledger_value_004}")
    print(f"    Calculated Final Balance (arithmetic operators only): {ledger_value_186:.2f}")
    print(f"    Generated History Steps: {len(ledger_value_056)}")

    # Trajectory Guard with short-circuit evaluation
    ledger_value_187 = [
        {"step": 1, "balance": 1500.0, "terminate": False},
        {"step": 2, "balance": 850.0, "terminate": False},
        {"step": 3, "balance": 45.0, "terminate": False}, # Falls below safety threshold 100.0
        {"step": 4, "balance": 2000.0, "terminate": False} # Must never be reached
    ]
    ledger_value_188 = check_trajectory_safety(ledger_value_187, ledger_value_018=100.0)
    print(f"  Trajectory Guard Evaluation:")
    print(f"    Halt Triggered: {ledger_value_188['halted']}")
    print(f"    Halt Reason   : {ledger_value_188['halt_reason']}")
    print(f"    Stopped Step  : {ledger_value_188['stopped_at_step']} (halted immediately via short-circuit)")

    # -----------------------------------------------------------------
    # UNIT 2 DEMONSTRATION: Log Parser & Closures
    # -----------------------------------------------------------------
    print("\n>>> [UNIT 2] Manual Log Parser & Stateful Closures")
    ledger_value_189 = [
        'Acc101,SAVINGS,"5,200.00",ACTIVE',
        'Acc102,"Current ""Special"" Account",15000.00',
        'Acc103,SAVINGS,,',
        'Acc104,"",0.00'
    ]
    print("  Manual Parser (no str.split, no str.replace, no csv):")
    for ledger_value_190 in ledger_value_189:
        ledger_value_071 = parse_delimited_record(ledger_value_190)
        print(f"    Raw: {ledger_value_190:<45} -> Tokens: {ledger_value_071}")

    # Stateful Audit Filter Closures
    print("  Stateful Audit Filter Closures (independent nonlocal counters):")
    ledger_value_191 = create_audit_filter(ledger_value_078=5000.0)
    ledger_value_192 = create_audit_filter(ledger_value_078=1000.0)

    ledger_value_193 = [
        ("A1", "SAVINGS", 6000.0),
        ("A2", "CURRENT", 2500.0),
        ("A3", "SAVINGS", 800.0)
    ]
    for ledger_value_194 in ledger_value_193:
        ledger_value_191(ledger_value_194)
        ledger_value_192(ledger_value_194)

    print(f"    Filter High (Threshold 5000) Stats: {ledger_value_191.get_stats()}")
    print(f"    Filter Low  (Threshold 1000) Stats: {ledger_value_192.get_stats()}")

    # Positional Lambda Filters avoiding late binding
    print("  Positional Criteria Lambdas (k=k default argument late-binding fix):")
    ledger_value_195 = [
        lambda ledger_value_106: ledger_value_106.startswith("Acc"),
        lambda ledger_value_106: ledger_value_106 in ("SAVINGS", "CURRENT", "CREDIT"),
        lambda ledger_value_106: float(ledger_value_106) >= 2000.0
    ]
    ledger_value_196 = build_position_filters(ledger_value_195)
    ledger_value_197 = ["Acc999", "SAVINGS", "3500.00"]
    ledger_value_198 = ledger_value_196[0](ledger_value_197) # tests position 0
    ledger_value_199 = ledger_value_196[1](ledger_value_197) # tests position 1
    ledger_value_200 = ledger_value_196[2](ledger_value_197) # tests position 2
    print(f"    Test Record: {ledger_value_197}")
    print(f"    Position 0 (Account ID format) : {ledger_value_198}")
    print(f"    Position 1 (Valid Type)        : {ledger_value_199}")
    print(f"    Position 2 (Balance threshold) : {ledger_value_200}")

    # -----------------------------------------------------------------
    # UNIT 3 DEMONSTRATION: Data Inversion & In-Place Processing
    # -----------------------------------------------------------------
    print("\n>>> [UNIT 3] Data Inversion & In-Place Processing")
    ledger_value_091 = {
        "BRANCH_01": [("Acc1@1", {"DEPOSIT", "UPI"}), ("Acc1@2", {"LOAN", "UPI"})],
        "BRANCH_02": [("Acc101", {"SAVINGS", "UPI"}), ("Acc103", {"CARD", "DEPOSIT"})]
    }
    ledger_value_201 = invert_service_catalog(ledger_value_091)
    print("  Single Dict Comprehension Service Inversion:")
    for ledger_value_202, ledger_value_203 in ledger_value_201.items():
        print(f"    {ledger_value_202:<10}: {ledger_value_203}")

    # In-place queue cleaning
    ledger_value_204 = [101, (3, 1, 2), {2, 4, 5, 7}, [10, 50, 20], 101, "TXN_A", 42, "TXN_A", 101]
    ledger_value_205 = id(ledger_value_204)
    print("\n  In-Place Transaction Queue Cleaning:")
    print(f"    Before Cleaning: {ledger_value_204}")
    clean_transaction_queue(ledger_value_204)
    print(f"    After Cleaning : {ledger_value_204}")
    print(f"    id(data_list) Unchanged: {id(ledger_value_204) == ledger_value_205} (id={ledger_value_205})")

    # -----------------------------------------------------------------
    # UNIT 4 DEMONSTRATION: File Engine & Logging
    # -----------------------------------------------------------------
    print("\n>>> [UNIT 4] File Engine: In-Place r+ Shifting & Database Auditing")
    ledger_value_206 = "accounts.db"
    ledger_value_207 = "ledger.txt"
    ledger_value_208 = "corrupted.log"

    # Setup database file with known records (including intentional corruption for audit test)
    with open(ledger_value_206, "w", newline="\n", encoding="utf-8") as ledger_value_119:
        ledger_value_119.write("Acc101,SAVINGS,5200.00\n")
        ledger_value_119.write("Acc102,CURRENT,15000.00\n")
        ledger_value_119.write("Acc103,CREDIT,3500.50\n")
        ledger_value_119.write("AccCORRUPT1,UNKNOWN_TYPE,1000.00\n")
        ledger_value_119.write("AccCORRUPT2,SAVINGS,INVALID_BALANCE\n")
        ledger_value_119.write("AccCORRUPT3,ONLY_TWO_FIELDS\n")
        ledger_value_119.write("Acc104,SAVINGS,9200.00\n")

    # Reset ledger and corrupted log
    with open(ledger_value_207, "w", newline="\n", encoding="utf-8") as ledger_value_119:
        ledger_value_119.write("")
    with open(ledger_value_208, "w", newline="\n", encoding="utf-8") as ledger_value_119:
        ledger_value_119.write("")

    print("  Initial Database Content:")
    with open(ledger_value_206, "r", newline="\n", encoding="utf-8") as ledger_value_119:
        for ledger_value_209 in ledger_value_119:
            print(f"    {ledger_value_209.strip()}")

    # Test in-place update with expansion and contraction
    print("\n  Testing in-place r+ update on 'Acc102' (Contracting payload to 99.00):")
    update_account_record_in_place(ledger_value_206, "Acc102", ledger_value_013=99.00)
    with open(ledger_value_206, "r", newline="\n", encoding="utf-8") as ledger_value_119:
        for ledger_value_209 in ledger_value_119:
            print(f"    {ledger_value_209.strip()}")

    print("\n  Testing in-place r+ update on 'Acc102' (Expanding payload to 12345678.99):")
    update_account_record_in_place(ledger_value_206, "Acc102", ledger_value_013=12345678.99)
    with open(ledger_value_206, "r", newline="\n", encoding="utf-8") as ledger_value_119:
        for ledger_value_209 in ledger_value_119:
            print(f"    {ledger_value_209.strip()}")

    # Audit the accounts database
    print("\n  Executing process_and_audit_accounts_file():")
    ledger_value_210 = audit_accounts_file(
        ledger_value_028=ledger_value_206,
        ledger_value_142=ledger_value_207,
        ledger_value_143=ledger_value_208
    )

    print(f"\n  Logged Corrupted Records (corrupted.log):")
    with open(ledger_value_208, "r", newline="\n", encoding="utf-8") as ledger_value_119:
        for ledger_value_211 in ledger_value_119:
            print(f"    {ledger_value_211.strip()}")

    # -----------------------------------------------------------------
    # UNIT 5 DEMONSTRATION: OOP & Polymorphic Batch Settlement
    # -----------------------------------------------------------------
    print("\n>>> [UNIT 5] OOP & Polymorphism: Subclasses & Batch Settlement")
    ledger_value_212 = SavingsAccount("SAV_01", 3000.00)
    ledger_value_213 = CurrentAccount("CURR_01", 2000.00, ledger_value_168=4000.00)
    ledger_value_214 = CreditAccount("CRED_01", 5000.00)

    # Name mangling demonstration
    print("  Demonstration of Python Encapsulation & Name Mangling:")
    print(f"    Mangled attribute access (acc_sav._BankAccount__balance) : {ledger_value_212._BankAccount__balance:.2f} (SUCCESS)")
    try:
        ledger_value_083 = ledger_value_212.__balance
    except AttributeError:
        print("    Direct private access (acc_sav.__balance)           : AttributeError (BLOCKED AS EXPECTED)")

    print(f"    Total Accounts Created Across System: {BankAccount.total_accounts}")

    # Polymorphic batch settlement
    ledger_value_215 = [
        SavingsAccount("SA_101", 2500.00), # 2500 - 1800 = 700 (< 1000 min) -> REJECTED
        CurrentAccount("CA_201", 500.00, ledger_value_168=2000.00), # 500 - 1800 = -1300 (> -2000) -> SUCCESS
        CreditAccount("CR_301", 3000.00),  # 1800 + 45 (2.5%) = 1845 (< 3000) -> SUCCESS
        SavingsAccount("SA_102", 5000.00)  # 5000 - 1800 = 3200 (> 1000 min) -> SUCCESS
    ]

    print("\n  Executing execute_batch_settlement(amount=1800.00) across mixed account types:")
    ledger_value_216 = execute_batch_settlement(ledger_value_215, 1800.00)
    print(f"    Successful Settlements: {ledger_value_216['success_count']}")
    for ledger_value_217 in ledger_value_216["success_logs"]:
        print(f"      [OK] Account: {ledger_value_217['account_id']} | Type: {ledger_value_217['type']} | New Balance: {ledger_value_217['new_balance']:.2f}")

    print(f"    Failed Settlements    : {ledger_value_216['failure_count']}")
    for ledger_value_218 in ledger_value_216["failure_logs"]:
        print(f"      [REJECTED] Account: {ledger_value_218['account_id']} | Type: {ledger_value_218['account_type']} | Error: {ledger_value_218['error']}")

    print("\n" + "=" * 75)
    print(" ALL UNIT DEMONSTRATIONS COMPLETED SUCCESSFULLY")
    print("=" * 75 + "\n")


# =====================================================================
# ENTRY POINT
# =====================================================================
if __name__ == "__main__":
    # 1. Run all comprehensive automated unit tests and demonstrations
    run_demonstrations()
    
    # 2. Launch the interactive CLI event loop
    # Pre-populate registry with sample accounts for immediate CLI testing
    ledger_value_219 = {
        "Acc101": SavingsAccount("Acc101", 5200.00),
        "Acc102": CurrentAccount("Acc102", 15000.00, ledger_value_168=5000.00),
        "Acc103": CreditAccount("Acc103", 3500.50)
    }
    
    print("[SYSTEM] Entering interactive CLI. (Type 'exit' to terminate, or press Ctrl+D)\n")
    try:
        run_interactive_cli(ledger_value_027=ledger_value_219, ledger_value_028="accounts.db")
    except (EOFError, KeyboardInterrupt):
        print("\n[SYSTEM] Terminating PTMAE engine.")
