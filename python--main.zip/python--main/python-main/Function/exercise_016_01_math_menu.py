def item_01(item_02, item_03):
    return item_02 + item_03

def item_04(item_02, item_03):
    return item_02 - item_03

def item_05(item_02, item_03):
    return item_02 * item_03

def item_06(item_02, item_03):
    return item_02 / item_03

def item_07(item_02, item_03):
    return item_02 // item_03

def item_08(item_02, item_03):
    return item_02 ** item_03
item_09 = {'1': item_01, '2': item_04, '3': item_05, '4': item_06, '5': item_07, '6': item_08}
print('1 Add  2 Subtract  3 Multiply  4 Divide  5 Integer Divide  6 Power')
item_10 = input('Choose: ')
item_02 = float(input('First number: '))
item_03 = float(input('Second number: '))
if item_10 in item_09:
    try:
        print('Result:', item_09[item_10](item_02, item_03))
    except ZeroDivisionError:
        print('Cannot divide by zero.')
else:
    print('Invalid choice.')
