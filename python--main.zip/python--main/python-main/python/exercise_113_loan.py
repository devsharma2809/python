item_01 = int(input("enter the income of the person: "))
print(item_01)

if item_01 >= 100000 :
    item_02 = 'premium loan'
elif item_01 >= 50000 :
    item_02 = 'standerend loan'
elif item_01 >= 25000 :
    item_02 = 'basic loan'
else :
    item_02 = 'not eligible'

print("the loan you get is : ",item_02)