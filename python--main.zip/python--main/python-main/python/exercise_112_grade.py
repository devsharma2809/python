item_01 = int(input("enter the marks of student"))
print(item_01)
if item_01 >= 90 :
    item_02 = 'A' 
elif item_01>= 80 :
    item_02 = 'B'
elif item_01 >= 70 :
    item_02 = 'C'
elif item_01 >= 60 :
    item_02 = 'D'
else :
    item_02 = 'F'

print("student gread is ", item_02)