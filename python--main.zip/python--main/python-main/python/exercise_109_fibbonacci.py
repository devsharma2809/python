item_01 =int(input("enter the number: "))
item_02=1
item_03=2
item_04 = None
print(item_02, item_05=" ")
print(item_03, item_05=" ")
while 1:
    item_04=item_02+item_03
    item_02=item_03
    item_03=item_04
    if(item_04>item_01) :
        break
    else :
        print(item_04, item_05="  ")
        