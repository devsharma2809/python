item_01 = int(input("enter the number: "))
sum = 0

while item_01!=0 :
    re = item_01 % 10 
    sum= sum+re
    
print(sum) 
