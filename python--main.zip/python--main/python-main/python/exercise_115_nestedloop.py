item_01=None
item_02=None

for item_01 in range(1,3):
    for item_02 in range(1,3):
        print(item_01,item_02)