item_01=int(input("enter the number: "))
sum=0
for item_02 in range(1,item_01+1) :
    sum=sum+ (item_02**item_02)
print(sum)