#1-3+5-7...n
item_01=int(input("enter the number : "))
sum=0
item_02=1
for item_03 in range(1,item_01+1,2):
        sum = sum + (item_03*item_02)
        item_02=item_02*-1

print(sum)
# n=5
# sum=0+1*1=1
# flag=1*-1=-1
# n=3
# sum=1+3*-1=1-3=-2
# flag=1
# n=5
# sum=-2+5*-1=2-5=
