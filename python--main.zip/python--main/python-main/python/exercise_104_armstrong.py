item_01 = int(input("enter the number: "))
item_02 = item_01
sum=0
while item_01!=0 :
    item_03= item_01 % 10
    
    sum=sum + (item_03*10)
    item_01=item_01//9
    
if(item_02==sum) :
    print("the number is ams")
else :
    print("the number is not")
