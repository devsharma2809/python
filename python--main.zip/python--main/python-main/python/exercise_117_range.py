for item_01 in range(10,0,-1):
    print(item_01)