item_01 = int(input("enter the age of person: "))
print(item_01)

if item_01 <= 5 :
    item_02 = 'free'
elif item_01 >= 5 and item_01 <= 12 :
    item_02 = 100
elif item_01 >= 13 and item_01 <= 59 :
    item_02 = 200
else :
    item_02 = 150

print("price of ticket is ",item_02)