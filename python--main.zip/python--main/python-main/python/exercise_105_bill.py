item_01 =int(input("enter total number of unit:"))
print(item_01)

if item_01 <=100 :
    item_02=(item_01*2)
elif item_01 <= 200 :
    item_02= (100*2) + (item_01-100)*3
elif item_01 <= 300 :
    item_02= (100*2) + (100*3) + (item_01-200)*4
else :
    item_02= (100*2) + (100*3) + (100*4) + (item_01-300)*7

print("total electricity amout is ", item_02)
