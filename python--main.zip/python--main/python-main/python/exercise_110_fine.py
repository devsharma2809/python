item_01 = int(input("enter the speed of vehicle: "))
print(item_01)

if item_01<=60 :
    item_02=0
elif item_01>=61 and item_01<=80 :
    item_02 =500
elif item_01>=81 and item_01<=100 :
    item_02=1000
else :
    item_02=2000

print("the fine is ", item_02)
