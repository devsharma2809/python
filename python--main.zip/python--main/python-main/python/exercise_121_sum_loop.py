sum=0
for item_01 in range(1,11):
    print(item_01)
    sum=sum + item_01
print(sum)

