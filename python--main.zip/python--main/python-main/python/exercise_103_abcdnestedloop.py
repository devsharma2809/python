
for item_01 in range(65,70) :
    for item_02 in range(65,item_01+1) :
        print(chr(item_02),item_03=" ")
    print()
    