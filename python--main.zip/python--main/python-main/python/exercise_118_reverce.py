item_01 =int(input("enter the number: "))
item_02= item_01
while item_01!=0 :
    re=item_01 % 10
    
    item_03=re // 9
print(item_03)
