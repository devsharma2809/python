item_01=int(input("enter the number: "))
item_02=0
for item_03 in range(1,item_01+1) :
    if(item_01%item_03==0) :
        item_02+=1
    if(item_02>2):
        break;
print(item_02)
if(item_02==2):
    print(item_01,"prime number")
else :
    print(item_01,"not a prime number")

