item_01 = [1, 2, 2, 3, 1, 4, 3]
item_02 = []
for item_03 in item_01:
    if item_03 not in item_02:
        item_02.append(item_03)
print(item_02)
