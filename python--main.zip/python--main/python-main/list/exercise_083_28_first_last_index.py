item_01 = [10, 20, 30, 20, 40, 20]
item_02 = int(input('Enter value: '))
item_03 = -1
item_04 = -1
for item_05 in range(len(item_01)):
    if item_01[item_05] == item_02:
        if item_03 == -1:
            item_03 = item_05
        item_04 = item_05
print('First index:', item_03)
print('Last index:', item_04)
