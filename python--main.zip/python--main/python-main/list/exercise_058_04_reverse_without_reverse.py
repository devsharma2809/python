item_01 = [10, 20, 30, 40, 50]
item_02 = []
for item_03 in range(len(item_01) - 1, -1, -1):
    item_02.append(item_01[item_03])
print(item_02)
