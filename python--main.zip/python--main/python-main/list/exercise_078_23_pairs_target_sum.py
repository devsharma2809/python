item_01 = [2, 4, 3, 5, 7, 8, 1]
item_02 = int(input('Enter target sum: '))
for item_03 in range(len(item_01)):
    for item_04 in range(item_03 + 1, len(item_01)):
        if item_01[item_03] + item_01[item_04] == item_02:
            print(item_01[item_03], item_01[item_04])
