item_01 = [[1, 2, 3], [4, 5, 6]]
item_02 = [item_03 for item_04 in item_01 for item_03 in item_04]
print(item_02)
