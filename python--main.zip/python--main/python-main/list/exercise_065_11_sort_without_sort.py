item_01 = [45, 12, 7, 31, 20]
item_02 = item_01[:]
for item_03 in range(len(item_02)):
    for item_04 in range(len(item_02) - 1):
        if item_02[item_04] > item_02[item_04 + 1]:
            item_02[item_04], item_02[item_04 + 1] = (item_02[item_04 + 1], item_02[item_04])
item_05 = item_02[::-1]
print('Ascending:', item_02)
print('Descending:', item_05)
