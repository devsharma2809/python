item_01 = [1, 2, 3, 4, 5, 6, 7, 8]
item_02 = []
item_03 = []
for item_04 in item_01:
    if item_04 % 2 == 0:
        item_02.append(item_04)
    else:
        item_03.append(item_04)
print('Even:', item_02)
print('Odd:', item_03)
