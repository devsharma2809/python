item_01 = [10, 20, 30, 40, 50]
item_02 = 0
for item_03 in item_01:
    item_02 += item_03
print('Sum:', item_02)
