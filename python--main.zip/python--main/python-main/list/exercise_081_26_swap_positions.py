item_01 = [10, 20, 30, 40, 50]
item_02 = int(input('First position: '))
item_03 = int(input('Second position: '))
item_01[item_02], item_01[item_03] = (item_01[item_03], item_01[item_02])
print(item_01)
