item_01 = [78, 85, 62, 91, 74, 88, 69, 95, 80, 72]
item_01.insert(2, 76)
item_01.remove(62)
item_01[0] = 82
item_01.sort()
print('Sorted:', item_01)
item_01.reverse()
print('Reversed:', item_01)
print('Highest:', max(item_01))
print('Lowest:', min(item_01))
print('Average:', sum(item_01) / len(item_01))
