item_01 = ['python', 'list', 'practice']
item_02 = [item_03.upper() for item_03 in item_01]
print(item_02)
