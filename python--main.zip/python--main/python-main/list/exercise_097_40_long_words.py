item_01 = input('Enter a sentence: ')
item_02 = item_01.split()
item_03 = [item_04 for item_04 in item_02 if len(item_04) > 5]
print(item_03)
