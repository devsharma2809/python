item_01 = [10, 20, 30, 40, 50]
print('First:', item_01[0])
print('Middle:', item_01[len(item_01) // 2])
print('Last:', item_01[-1])
