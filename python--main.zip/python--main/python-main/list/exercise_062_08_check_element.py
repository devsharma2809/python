item_01 = ['pen', 'book', 'bag', 'scale']
item_02 = input('Enter item to search: ')
if item_02 in item_01:
    print('Element exists.')
else:
    print('Element does not exist.')
