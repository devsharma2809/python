item_01 = [1, 2, 1, 3, 2, 1]
item_02 = {}
for item_03 in item_01:
    item_02[item_03] = item_02.get(item_03, 0) + 1
print(item_02)
