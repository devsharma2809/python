item_01 = [10, 20, 30]
item_02 = item_01.copy()
item_02.append(40)
print('Original:', item_01)
print('Copy:', item_02)
