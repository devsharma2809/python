item_01 = []
for item_02 in range(2, 101):
    item_03 = True
    for item_04 in range(2, item_02):
        if item_02 % item_04 == 0:
            item_03 = False
            break
    if item_03:
        item_01.append(item_02)
print(item_01)
