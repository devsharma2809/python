item_01 = [item_02 * item_02 for item_02 in range(1, 21)]
print(item_01)
