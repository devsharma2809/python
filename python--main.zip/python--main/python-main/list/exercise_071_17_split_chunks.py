item_01 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
item_02 = int(input('Enter chunk size: '))
item_03 = []
for item_04 in range(0, len(item_01), item_02):
    item_03.append(item_01[item_04:item_04 + item_02])
print(item_03)
