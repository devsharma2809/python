item_01 = [10, 15, 20, 30, 45, 60, 75]
item_02 = [item_03 for item_03 in item_01 if item_03 % 3 == 0 and item_03 % 5 == 0]
print(item_02)
