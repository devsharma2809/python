item_01 = [1, 2, 3, 2, 4, 2, 5]
item_02 = int(input('Enter value to remove: '))
item_03 = []
for item_04 in item_01:
    if item_04 != item_02:
        item_03.append(item_04)
print(item_03)
