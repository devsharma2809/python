item_01 = [1, 2, 3, 4]
item_02 = [3, 4, 5, 6]
print('Intersection:', list(set(item_01) & set(item_02)))
print('Union:', list(set(item_01) | set(item_02)))
print('Difference:', list(set(item_01) - set(item_02)))
