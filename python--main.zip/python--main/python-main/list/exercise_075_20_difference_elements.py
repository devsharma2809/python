item_01 = [1, 2, 3, 4, 5]
item_02 = [3, 4, 6]
item_03 = []
for item_04 in item_01:
    if item_04 not in item_02:
        item_03.append(item_04)
print(item_03)
