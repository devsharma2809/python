item_01 = [1, 2, 3, 2, 1]
if item_01 == item_01[::-1]:
    print('Palindrome list')
else:
    print('Not a palindrome list')
