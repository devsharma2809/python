item_01 = [1, 2, 3, 4, 5, 6]
item_02 = {'even': [], 'odd': []}
for item_03 in item_01:
    if item_03 % 2 == 0:
        item_02['even'].append(item_03)
    else:
        item_02['odd'].append(item_03)
print(item_02)
