item_01 = [65, 72, 80, 91, 77]
item_02 = 0
for item_03 in item_01:
    item_02 += item_03
print('Average:', item_02 / len(item_01))
