item_01 = ['p', 'y', 't', 'h', 'o', 'n', 'a', 'e']
item_02 = [item_03 for item_03 in item_01 if item_03.lower() not in 'aeiou']
print(item_02)
