item_01 = [100, 4, 200, 1, 3, 2, 5]
item_02 = set(item_01)
item_03 = 0
for item_04 in item_02:
    if item_04 - 1 not in item_02:
        item_05 = 1
        while item_04 + item_05 in item_02:
            item_05 += 1
        if item_05 > item_03:
            item_03 = item_05
print('Longest consecutive length:', item_03)
