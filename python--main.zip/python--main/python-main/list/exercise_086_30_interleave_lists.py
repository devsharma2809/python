item_01 = [1, 3, 5]
item_02 = [2, 4, 6]
item_03 = []
for item_04 in range(len(item_01)):
    item_03.append(item_01[item_04])
    item_03.append(item_02[item_04])
print(item_03)
