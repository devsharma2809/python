item_01 = ['pen', 'pencil', 'eraser']
item_01.append('book')
item_01.insert(1, 'marker')
item_01.remove('pencil')
print(item_01)
