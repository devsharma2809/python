item_01 = ['Python', None, '', 'Java', 0, [], 'List']
item_02 = []
for item_03 in item_01:
    if item_03 is not None and item_03 != '':
        item_02.append(item_03)
print(item_02)
