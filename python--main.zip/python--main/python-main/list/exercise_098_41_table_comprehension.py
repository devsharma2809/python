item_01 = [[item_02 * item_03 for item_03 in range(1, 11)] for item_02 in range(1, 11)]
for item_04 in item_01:
    print(item_04)
