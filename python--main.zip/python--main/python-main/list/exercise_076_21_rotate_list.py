item_01 = [1, 2, 3, 4, 5]
item_02 = int(input('Enter positions: ')) % len(item_01)
print('Left:', item_01[item_02:] + item_01[:item_02])
print('Right:', item_01[-item_02:] + item_01[:-item_02])
