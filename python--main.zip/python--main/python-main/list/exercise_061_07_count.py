item_01 = [10, 20, 10, 30, 10, 40]
item_02 = int(input('Enter value to count: '))
item_03 = 0
for item_04 in item_01:
    if item_04 == item_02:
        item_03 += 1
print('Occurrences:', item_03)
