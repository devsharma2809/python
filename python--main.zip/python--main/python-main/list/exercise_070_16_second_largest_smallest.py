item_01 = [12, 45, 7, 31, 20, 45]
item_02 = []
for item_03 in item_01:
    if item_03 not in item_02:
        item_02.append(item_03)
item_02.sort()
print('Second smallest:', item_02[1])
print('Second largest:', item_02[-2])
