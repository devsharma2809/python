item_01 = [1, 2, 3]
item_02 = [4, 5, 6]
item_03 = item_01 + item_02
print(item_03)
