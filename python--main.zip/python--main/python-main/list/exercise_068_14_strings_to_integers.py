item_01 = ['10', '20', '30', '40']
item_02 = []
for item_03 in item_01:
    item_02.append(int(item_03))
print(item_02)
