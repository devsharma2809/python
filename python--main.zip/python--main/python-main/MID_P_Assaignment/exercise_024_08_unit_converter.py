"""Program 1.8: kilometre converter."""

item_01 = float(input("Enter distance in kilometres: "))
print("Metres:", round(item_01 * 1000, 2))
print("Centimetres:", round(item_01 * 100000, 2))
print("Miles:", round(item_01 * 0.621371, 2))
print("Feet:", round(item_01 * 3280.84, 2))
