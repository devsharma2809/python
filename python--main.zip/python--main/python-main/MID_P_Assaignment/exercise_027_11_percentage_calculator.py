"""Program 1.11: marks, percentage and average."""

item_01 = []
for item_02 in range(1, 6):
    item_01.append(float(input("Enter marks for subject " + str(item_02) + ": ")))
item_03 = sum(item_01)
print("Total:", round(item_03, 2), "/500")
print("Percentage:", round(item_03 / 5, 2), "%")
print("Average:", round(item_03 / 5, 2))
