"""Program 1.12: electric bill calculator."""

item_01 = float(input("Enter previous meter reading: "))
item_02 = float(input("Enter current meter reading: "))
item_03 = item_02 - item_01
if item_03 < 0:
    print("Current reading cannot be less than previous reading.")
else:
    print("Units consumed:", round(item_03, 2))
    print("Total bill: Rs.", round(item_03 * 5.50 + 100, 2))
