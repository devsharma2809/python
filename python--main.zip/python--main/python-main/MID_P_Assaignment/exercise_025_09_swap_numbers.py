"""Program 1.9: swap two numbers in two ways."""

item_01 = float(input("Enter first number: "))
item_02 = float(input("Enter second number: "))
item_03, item_04 = item_01, item_02
print("Before swap: a =", item_01, ", b =", item_02)
item_01, item_02 = item_02, item_01
print("Tuple swap: a =", item_01, ", b =", item_02)
item_01, item_02 = item_03, item_04
item_01 = item_01 + item_02
item_02 = item_01 - item_02
item_01 = item_01 - item_02
print("Arithmetic swap: a =", item_01, ", b =", item_02)
