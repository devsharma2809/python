"""Program 1.1: print basic student details."""

item_01 = "Your Full Name"
item_02 = "Your Roll Number"
item_03 = "M.Sc. IT"
item_04 = "Semester 1"

print(item_01)
print(item_02)
print(item_03)
print(item_04)
