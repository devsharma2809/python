"""Program 1.7: extract digits of a three-digit number."""

item_01 = int(input("Enter a three-digit number: "))
if 100 <= abs(item_01) <= 999:
    item_01 = abs(item_01)
    item_02, item_03 = divmod(item_01, 100)
    item_04, item_05 = divmod(item_03, 10)
    print("Hundreds:", item_02)
    print("Tens:", item_04)
    print("Units:", item_05)
    print("Sum:", item_02 + item_04 + item_05)
    print("Product:", item_02 * item_04 * item_05)
else:
    print("Please enter exactly a three-digit number.")
