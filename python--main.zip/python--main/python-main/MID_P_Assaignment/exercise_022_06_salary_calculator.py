"""Program 1.6: salary calculator."""

item_01 = float(input("Enter basic salary: "))
item_02 = item_01 * 0.20
item_03 = item_01 * 0.10
item_04 = item_01 * 0.12
item_05 = item_01 + item_02 + item_03
print("Gross salary:", round(item_05, 2))
print("Net salary:", round(item_05 - item_04, 2))
