"""Program 1.4: Celsius to Fahrenheit and Kelvin."""

item_01 = float(input("Enter temperature in Celsius: "))
item_02 = item_01 * 9 / 5 + 32
item_03 = item_01 + 273.15
print("Fahrenheit:", round(item_02, 2), "F")
print("Kelvin:", round(item_03, 2), "K")
