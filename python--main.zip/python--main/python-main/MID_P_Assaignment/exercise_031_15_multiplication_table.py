"""Program 1.15: multiplication table."""

item_01 = int(input("Enter a number: "))
for item_02 in range(1, 11):
    print(item_01, "x", item_02, "=", item_01 * item_02)
