"""Program 1.20: star pattern collection."""
item_01 = 5
print("Right-angled triangle")
for item_02 in range(1, item_01 + 1): print("*" * item_02)
print("Inverted triangle")
for item_02 in range(item_01, 0, -1): print("*" * item_02)
print("Diamond")
for item_02 in range(1, item_01 + 1, 2): print(" " * ((item_01 - item_02) // 2) + "*" * item_02)
for item_02 in range(item_01 - 2, 0, -2): print(" " * ((item_01 - item_02) // 2) + "*" * item_02)
