"""Program 1.16: factorial using a for loop."""
item_01 = int(input("Enter a non-negative integer: "))
if item_01 < 0:
    print("Factorial is not defined for negative numbers.")
else:
    item_02 = 1
    for item_03 in range(2, item_01 + 1):
        item_02 *= item_03
    print(item_01, "! =", item_02)
