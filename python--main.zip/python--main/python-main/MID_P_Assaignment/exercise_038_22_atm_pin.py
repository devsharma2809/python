"""Program 1.22: ATM PIN simulator."""
item_01 = "1234"
item_02 = 0
while item_02 < 3:
    item_03 = input("Enter your 4-digit PIN: ")
    if item_03 == item_01:
        print("Access Granted")
        break
    item_02 += 1
    print("Incorrect PIN")
else:
    print("Card Blocked")
