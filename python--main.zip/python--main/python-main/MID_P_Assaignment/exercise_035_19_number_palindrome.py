"""Program 1.19: reverse and test a number."""
item_01 = int(input("Enter a non-negative number: "))
if item_01 < 0:
    print("Please enter a non-negative number.")
else:
    item_02, item_03 = item_01, 0
    while item_02 > 0:
        item_03 = item_03 * 10 + item_02 % 10
        item_02 //= 10
    print("Reversed number:", item_03)
    print("It is a palindrome." if item_01 == item_03 else "It is not a palindrome.")
