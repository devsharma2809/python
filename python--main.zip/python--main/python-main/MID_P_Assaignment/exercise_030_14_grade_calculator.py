"""Program 1.14: grade calculator."""

item_01 = float(input("Enter marks: "))
if item_01 >= 90:
    item_02 = "A+"
elif item_01 >= 80:
    item_02 = "A"
elif item_01 >= 70:
    item_02 = "B"
elif item_01 >= 60:
    item_02 = "C"
elif item_01 >= 35:
    item_02 = "D"
else:
    item_02 = "Fail"
print("Grade:", item_02)
if item_01 >= 90:
    print("Distinction")
