"""Program 1.21: Armstrong number checker and finder."""
def item_01(item_02):
    item_03 = str(item_02)
    return item_02 == sum(int(item_04) ** len(item_03) for item_04 in item_03)

item_02 = int(input("Enter a number: "))
if item_01(item_02):
    print(item_02, "is an Armstrong number.")
else:
    print(item_02, "is not an Armstrong number.")
print("Armstrong numbers from 1 to 999:")
print(*[item_05 for item_05 in range(1, 1000) if item_01(item_05)])
