"""Program 1.17: check a prime and list primes."""
def item_01(item_02):
    if item_02 < 2:
        return False
    for item_03 in range(2, int(item_02 ** 0.5) + 1):
        if item_02 % item_03 == 0:
            return False
    return True

item_02 = int(input("Enter N: "))
if item_01(item_02):
    print(item_02, "is prime.")
else:
    print(item_02, "is not prime.")
print("Primes from 2 to N:", *[item_04 for item_04 in range(2, item_02 + 1) if item_01(item_04)])
