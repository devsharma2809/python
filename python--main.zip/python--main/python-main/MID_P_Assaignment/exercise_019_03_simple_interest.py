"""Program 1.3: simple interest calculator."""

item_01 = float(input("Enter principal amount: "))
item_02 = float(input("Enter annual rate (%): "))
time = float(input("Enter time (years): "))
item_03 = item_01 * item_02 * time / 100
print("Simple interest:", round(item_03, 2))
print("Total amount:", round(item_01 + item_03, 2))
