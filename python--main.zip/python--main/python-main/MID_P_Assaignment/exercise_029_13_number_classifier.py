"""Program 1.13: classify a number."""

item_01 = int(input("Enter an integer: "))
item_02 = "positive" if item_01 > 0 else "negative" if item_01 < 0 else "zero"
item_03 = "even" if item_01 % 2 == 0 else "odd"
item_04 = "is" if item_01 % 5 == 0 else "is not"
print("The number is", item_02 + ",", item_03 + ", and", item_04, "divisible by 5.")
