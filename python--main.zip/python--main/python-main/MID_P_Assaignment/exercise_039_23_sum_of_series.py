"""Program 1.23: sums of natural numbers, squares and cubes."""
item_01 = int(input("Enter N: "))
item_02 = item_03 = item_04 = 0
for item_05 in range(1, item_01 + 1):
    item_02 += item_05
    item_03 += item_05 ** 2
    item_04 += item_05 ** 3
print("Natural number sum:", item_02)
print("Square sum:", item_03)
print("Cube sum:", item_04)
