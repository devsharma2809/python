"""Program 1.2: formatted introduction."""

item_01 = input("Enter your name: ")
item_02 = input("Enter your age: ")
item_03 = input("Enter your favourite city: ")
print("Hello! My name is " + item_01 + ". I am " + item_02 + " years old and I love " + item_03 + ".")
