"""Program 1.10: BMI calculator."""

item_01 = float(input("Enter weight in kg: "))
item_02 = float(input("Enter height in metres: "))
if item_02 <= 0:
    print("Height must be greater than zero.")
else:
    item_03 = item_01 / item_02 ** 2
    if item_03 < 18.5:
        item_04 = "Underweight"
    elif item_03 < 25:
        item_04 = "Normal"
    elif item_03 < 30:
        item_04 = "Overweight"
    else:
        item_04 = "Obese"
    print("BMI:", round(item_03, 2), "(" + item_04 + ")")
