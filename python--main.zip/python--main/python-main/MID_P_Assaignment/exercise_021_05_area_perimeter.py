"""Program 1.5: rectangle and circle calculations."""

from math import pi

item_01 = float(input("Enter rectangle length: "))
item_02 = float(input("Enter rectangle breadth: "))
print("Rectangle area:", round(item_01 * item_02, 2))
print("Rectangle perimeter:", round(2 * (item_01 + item_02), 2))
print("Circle area (radius = length):", round(pi * item_01 ** 2, 2))
