"""Program 1.18: Fibonacci series with while loop."""
item_01 = int(input("How many terms? "))
item_02, item_03, item_04 = 0, 1, 0
while item_04 < item_01:
    print(item_02, item_05=" ")
    item_02, item_03 = item_03, item_02 + item_03
    item_04 += 1
print()
