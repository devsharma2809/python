item_01 = [25, 10, 45, 5, 30]

item_02 = item_01[0]
item_03 = item_01[0]

for item_04 in item_01:
    if item_04 > item_02:
        item_02 = item_04

    if item_04 < item_03:
        item_03 = item_04

print("Maximum =", item_02)
print("Minimum =", item_03)