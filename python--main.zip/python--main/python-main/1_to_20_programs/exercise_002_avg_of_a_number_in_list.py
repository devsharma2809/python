item_01 = [10, 20, 30, 40, 60, 99, 1, 50]

item_02 = 0
for item_03 in item_01:
    item_02 += item_03
item_04 = item_02 / len(item_01)

print("Average =", item_04)