item_01 = [10, 20, 30, 40, 50, 60, 70]

item_02 = item_01[0]
item_03 = item_01[-1]
item_04 = item_01[len(item_01) // 2]

print("First element :", item_02)
print("Middle element:", item_04)
print("Last element  :", item_03)