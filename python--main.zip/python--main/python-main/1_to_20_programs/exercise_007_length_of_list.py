item_01 = [10, 20, 30, 40, 50, 60, 80, 120, 47, 43, 54, 57, 69]

item_02 = len(item_01)

print("Length of list =", item_02)