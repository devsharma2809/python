item_01 = [10, 20, 30, 20, 40, 20, 50]

item_02 = int(input("Enter number: "))

item_03 = 0
for item_04 in item_01:
    if item_04 == item_02:
        item_03 += 1

print(item_02, "appears", item_03, "times")