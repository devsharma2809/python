item_01 = [10, 20, 30, 40]

print("Original List:", item_01)

item_01.append(50)

print("After Append:", item_01)

item_01.insert(2, 25)

print("After Insert:", item_01)

item_01.remove(30)

print("After Remove:", item_01)