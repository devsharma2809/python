item_01 = [15, 27, 43, 68]
item_02 = [43, 68, 91, 24]

item_03 = []

for item_04 in item_01:
    if item_04 in item_02:
        item_03.append(item_04)

print("Common Elements:", item_03)