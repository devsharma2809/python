item_01 = [23, 58, 14, 91, 37]
item_01.sort()
print("Second Smallest =", item_01[1])
print("Second Largest =", item_01[-2])