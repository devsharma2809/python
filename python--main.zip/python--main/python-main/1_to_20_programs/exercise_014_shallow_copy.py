item_01 = ["Dev", "Maahi", "Dhruv"]

item_02 = item_01.copy()

item_02.append("Pooja")

print("Original List:", item_01)
print("Copied List:", item_02)