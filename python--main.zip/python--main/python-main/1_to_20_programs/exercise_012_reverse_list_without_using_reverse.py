item_01 = [10123, 2022, 301, 401, 540]

item_02 = []
for item_03 in range(len(item_01) - 1, -1, -1):
    item_02.append(item_01[item_03])

print("Original List :", item_01)
print("Reversed List:", item_02)