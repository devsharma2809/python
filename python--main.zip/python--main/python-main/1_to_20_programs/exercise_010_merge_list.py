item_01 = ["Dev", "vatsal", "manav"]
item_02 = ["dhaval", "yash", "Pooja"]

item_03 = item_01 + item_02

print("Merged List:", item_03)