item_01 = [10, 20, 30, 40, 50, 601, 42, 32, 67]

item_02 = int(input("Enter number: "))

if item_02 in item_01:
    print("Element Found")
else:
    print("Element Not Found")