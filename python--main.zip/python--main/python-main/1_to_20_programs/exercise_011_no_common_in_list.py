item_01 = [18, 35, 47, 62]
item_02 = [35, 51, 78, 90]

item_03 = []
item_04 = []

for item_05 in item_01:
    if item_05 not in item_02:
        item_03.append(item_05)

for item_05 in item_02:
    if item_05 not in item_01:
        item_04.append(item_05)
print("Elements only in List1:", item_03)
print("Elements only in List1:", item_04)

print("----------------------------------------------")
print("                    OR                        ")
print("----------------------------------------------")

item_01 = [18, 35, 47, 62]
item_02 = [35, 51, 78, 90]
item_03 = []
for item_05 in item_01:
    if item_05 not in item_02:
        item_03.append(item_05)

print("Elements only in List1:", item_03)
